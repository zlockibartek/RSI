﻿using ClientProxy.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ClientProxy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now);
            Console.WriteLine("Bartłomiej Złocki 256766");
            Console.WriteLine(Environment.UserName);
            Console.WriteLine(Environment.OSVersion.ToString());
            Console.WriteLine(Environment.Version.ToString());
            Console.WriteLine(Dns.GetHostEntry(Dns.GetHostName()).AddressList[0].ToString());

            Console.WriteLine("\nA:");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("B:");
            double b = double.Parse(Console.ReadLine());

            CalculatorClient client1 = new CalculatorClient("WSHttpBinding_ICalculator");
            CalculatorClient client2 = new CalculatorClient("BasicHttpBinding_ICalculator");
            CalculatorClient client3 = new CalculatorClient("myEndpoint3");

            Console.WriteLine("\n\n---------- WSHttpBinding Calculator ----------");
            

            double result = client1.Add(a, b);
            Console.WriteLine(result);

            result = client1.Subtract(a, b);
            Console.WriteLine(result);

            result = client1.Multiply(a, b);
            Console.WriteLine(result);

            result = client1.Divide(a, b);
            Console.WriteLine(result);

            result = client1.Summarize(a);
            Console.WriteLine(result);

            client1.Close();

            Console.WriteLine("\n\n---------- BasicHttpBinding Calculator ----------");

            result = client2.Add(a, b);
            Console.WriteLine(result);

            result = client2.Subtract(a, b);
            Console.WriteLine(result);

            result = client2.Multiply(a, b);
            Console.WriteLine(result);

            result = client2.Divide(a, b);
            Console.WriteLine(result);

            result = client2.Summarize(a);
            Console.WriteLine(result);

            client2.Close();

            Console.WriteLine("\n\n---------- myEndpoint3 Calculator ----------");

            result = client3.Add(a, b);
            Console.WriteLine(result);

            result = client3.Subtract(a, b);
            Console.WriteLine(result);

            result = client3.Multiply(a, b);
            Console.WriteLine(result);

            result = client3.Divide(a, b);
            Console.WriteLine(result);

            result = client3.Summarize(a);
            Console.WriteLine(result);

            client3.Close();

            Console.ReadKey();
        }
    }
}
